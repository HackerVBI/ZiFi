<?php
$allowedHosts = [
    'zxaaa.untergrund.net',
    'vtrdos.ru',
    'prods.tslabs.info',
    'forum.tslabs.info',
    'zx.kaniv.net',
    'events.retroscene.org',
    'ftp.cc.org.ru',
    'files.scene.org',
];
if (class_exists('ZipArchive')) {
    if (isset($_GET['f'])) {
        $currentPath = dirname(__FILE__);
        $temporaryPath = $currentPath . '/ziptmp/';
        if (!is_dir($temporaryPath)) {
            mkdir($temporaryPath);
        }
        $remotePath = $_GET['f'];
        $parse = parse_url($remotePath);
        if (in_array($parse['host'], $allowedHosts)) {
            parse_str($parse['query'], $parameters);
            if (isset($parameters['f'])) {
                if ($remoteName = pathinfo($parameters['f'], PATHINFO_BASENAME)) {
                    if ($content = file_get_contents($remotePath)) {
                        $filePath = $temporaryPath . $remoteName;
                        file_put_contents($filePath, $content);
                        if (is_file($filePath)) {
                            $zip = new ZipArchive();
                            if ($res = $zip->open($filePath)) {
                                for ($i = 0; $i < $zip->numFiles; $i++) {
                                    if ($fileName = $zip->getNameIndex($i)) {
                                        if ($extension = pathinfo($fileName, PATHINFO_EXTENSION)) {
                                            $extension = strtolower($extension);
                                            if ($extension == 'scl' || $extension == 'trd' || $extension == 'spg') {
                                                $file = $zip->extractTo($temporaryPath, [$fileName]);
                                                readfile($temporaryPath . $fileName);
                                                unlink($temporaryPath . $fileName);
                                                exit;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
            }
        }
    } else {
        die ('no file');
    }
} else {
    die ('no ZipArchive support');
}